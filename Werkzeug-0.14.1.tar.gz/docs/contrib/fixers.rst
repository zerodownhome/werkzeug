======
Fixers
======

.. automodule:: werkzeug.contrib.fixers

.. autoclass:: CGIRootFix

.. autoclass:: PathInfoFromRequestUriFix

.. autoclass:: ProxyFix
   :members:

.. autoclass:: HeaderRewriterFix

.. autoclass:: InternetExplorerFix
